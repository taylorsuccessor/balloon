<?php
// Heading
$_['heading_title']    = 'Advanced Newsletter Subscribe';

$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified Advanced Newsletter Subscribe module!';
$_['text_status_success']     = 'Success: You have updated status for emails!';
$_['text_delete_success']     = 'Success: You have deleted email!';
$_['text_edit']        = 'Edit Advanced Newsletter Subscribe Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Advanced Newsletter Subscribe module!';
Thanks for using my module. For install module, please go to http://wiki.opcartstore.com/w/index.php/How_to_install_module_on_opencart_2.x and follow my guide.

If you have any issue, please create for me one ticket via:

http://jira.opcartstore.com


Also, if you interesting another my modules, please viti my page on opencart.com

http://www.opencart.com/index.php?route=extension/extension&filter_username=woccorp